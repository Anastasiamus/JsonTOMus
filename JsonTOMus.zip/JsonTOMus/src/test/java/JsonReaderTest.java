import org.apache.tomcat.util.json.JSONParser;
import org.apache.tomcat.util.json.ParseException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;


/* Приложеный файл нужно проверять на:
- Что он удовлетворяет JSON требованиям
- Что структура соответствует заданной
- Что отсутствуют лишние пробелы, переносы, символы и любые другие артефакты
- Что в вопросах только один правильный ответ
- Что в вопросах не повторяются тексты ответов
- Что в вопросах с картинкой, картинка есть в описании*/



//Нужно проверять, что длинну ответов, если число ответов равно:
// 2: то в ответе будет не более 120 символов,
// 3: 90,
// 4: 60
public class JsonReaderTest {

    @Test
    public void testLength() {
        try (FileReader reader = new FileReader("src/test/java/questions.json")) {
            StringBuilder jsonString = new StringBuilder();
            int character;
            while ((character = reader.read()) != -1) {
                jsonString.append((char) character);
            }
            JSONArray jsonArray = new JSONArray(jsonString.toString());

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String uniqueId = jsonObject.getString("uniqueId");
                JSONArray options = jsonObject.getJSONArray("options"); //  Этот метод извлекает из jsonObject массив по ключу "options". Ключ "options" указывает на массив, содержащий доступные варианты ответов на некоторый вопрос, хранящийся в JSON-файле.
                int numAnswers = options.length();
                int maxLength = 0;

                if (numAnswers == 2) {
                    maxLength = 120;
                } else if (numAnswers == 3) {
                    maxLength = 90;
                } else if (numAnswers == 4) {
                    maxLength = 60;
                }

                for (int j = 0; j < options.length(); j++) {
                    JSONObject answer = options.getJSONObject(j);
                    String text = answer.getString("text");

                    if (text.length() > maxLength) {
                       // System.out.println(" Peremennaya ravna " + text.length());
                        Assert.assertTrue("В блоке с UniqueID: " + uniqueId + " Длина ответа \"" + text + "\" превышает максимально допустимую длину." ,maxLength > text.length());
                       // System.out.println("Длина ответа \"" + text + "\" превышает максимально допустимую длину.");
                    }
                }
            }
        } catch (IOException | JSONException e) {
            throw new RuntimeException(e);
        }
    }


    //- Что все названия уникальны
    @Test
    public void UniqueNamesChecker(){
        try (BufferedReader reader = new BufferedReader(new FileReader("src/test/java/questions.json"))) {
            StringBuilder jsonString = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                jsonString.append((line));
            }
            JSONArray jsonArray = new JSONArray(jsonString.toString());

            Set<String> names = new HashSet<>();
            int lineNumber = 0;

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String uniqueName = jsonObject.getString("uniqueId");

                if (names.contains(uniqueName)) {
                    lineNumber = i;
                    System.out.println(i);
                    System.out.println("Обнаружено дублирующееся название: " + uniqueName  + " в строке " + lineNumber);
                    Assert.assertTrue(Boolean.parseBoolean("Обнаружено дублирующееся название: " + uniqueName + " в строке " + lineNumber));
                    return;
                } else {
                    names.add(uniqueName);
                }
            }
            System.out.println("Проверка прошла успешно.Все названия уникальны.Поздравляю!");

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
    }
}



        // - Что в вопросах только один правильный ответ







